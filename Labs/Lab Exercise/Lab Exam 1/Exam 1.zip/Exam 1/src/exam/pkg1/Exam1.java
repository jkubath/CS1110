/* Lab Exam 1 - Jonah Kubath
 * October 17, 2016
 *
 *
 */
package exam.pkg1;
 
import javax.swing.JOptionPane;

public class Exam1 {

    public static void main(String[] args) {

        String input;
        double number = 0;
        int total = 0;
        boolean evenCheck;
        int even = 0, odd = 0;
        char anotherInteger;

        do {
            //Get the number from the user
            input = JOptionPane.showInputDialog("Enter an integer. \n"
                    + "(Between 1 and 1000)");
            number = Double.parseDouble(input);

            //Data validation
            while (number < 1 || number > 1000 || number % 1 != 0) {
                input = JOptionPane.showInputDialog("Invalid entry.\n"
                        + "Enter an integer from 1 to 1000");
                number = Double.parseDouble(input);
            }

            //Call method to add the digits and return the total
            total = addsAllTheDigits(input);

            //Print the total
            System.out.println("The summation of all the digits is: "
                    + total);

            //Checks to see if it is even or odd
            evenCheck = isEven(total);

            //Counter for the even and odd numbers entered
            if (evenCheck) {
                even++;
            } else {
                odd++;
            }

            //Would the user like to continue
            input = JOptionPane.showInputDialog("Woud you like to enter another"
                    + " integer?\n (Yes or No)");
            input = input.toUpperCase();
            anotherInteger = input.charAt(0);

        } while (anotherInteger == 'Y');

        //Print out the count of odds and evens
        System.out.println();
        System.out.println("The count of integer numbers that the summation of"
                + " their digits is odd:  " + odd);
        System.out.println("The count of integer numbers that the summation of"
                + " their digits is even: " + even);

    }

    public static int addsAllTheDigits(String input) {
        int total = 0;
        int number = 0;
        char oneNumber;
        String oneNumberStr;

        //Run the loop through all the digits
        for (int i = 0; i < input.length(); i++) {
            //Get the character in the i spot
            oneNumber = input.charAt(i);
            //Convert it to string
            oneNumberStr = "" + oneNumber;
            //Convert it to a integer
            number = Integer.parseInt(oneNumberStr);
            //Add it to the total
            total += number;
        }

        return total;

    }

    public static boolean isEven(int total) {
        boolean isEven = true;
        if (total % 2 != 0) {
            //System.out.println("The total is odd.");
            isEven = false;

        } else {
            //System.out.println("The total is even.");
            isEven = true;
        }

        return isEven;
    }
}
