/* PROJECT: RideShare
 * AUTHOR:  Jonah Kubath
 * Lab Section: Monday at 12:30-2:20
 * Assignment: Lab1
 * DESCRIPTION: RideShare APP
 ******************************************************************************/
import javax.swing.JOptionPane;

public class RideShare {

    public static void main(String[] args) {

//        WRITE main's CODE HERE
//        Stage 1
//        int a = 10, b = 20, result = 0;
//        result = a + b;
//        System.out.println(result);
//
//        Stage 2
//        User input
//        String aString, bString;
//        aString = JOptionPane.showInputDialog("Enter A");
//        bString = JOptionPane.showInputDialog("Enter B");
//
//        Converting string to int
//        int a = 0, b = 0, result;
//        a = Integer.parseInt(aString);
//        b = Integer.parseInt(bString);
//        result = a + b;
//
//        Print the inputs and result
//        System.out.println("A = " + a);
//        System.out.println("B = " + b);
//        System.out.println("Result = " + result);

//          RideShare Stage 1 - Use predesignated variables
            /*double classMeet = 3, semesterWeek = 15, milesPG = 18, 
                gasCost = 2.12, travelDis = 23, oneRoundTrip, tripsSemester,
                totalMiles, totalCost, totalSharedOne, totalSharedTwo;

            */  
        
        //RideShare Stage 2 - User Defined variables
        double classMeet = 0, semesterWeek = 0, milesPG = 0, gasCost = 0, 
                travelDis = 0, oneRoundTrip = 0, tripsSemester = 0,
                totalMiles = 0, totalCost = 0, totalSharedOne = 0, 
                totalSharedTwo = 0;
        
        String inputClassMeet, inputSemesterWeek, inputMPG, inputGasCost, 
                inputTravelDis;

        inputClassMeet = JOptionPane.showInputDialog("How many times a week" + 
                " does your class meet?");
        inputSemesterWeek = JOptionPane.showInputDialog("How many weeks are"
                + " in your semester?");
        inputMPG = JOptionPane.showInputDialog("How many miles per gallon" + 
                " does your car get?");
        inputGasCost = JOptionPane.showInputDialog("What is the current" + 
                " price of gas?	($) ");
        inputTravelDis = JOptionPane.showInputDialog("How many miles away" + 
                " are you from your class?");

        classMeet = Double.parseDouble(inputClassMeet);
        semesterWeek = Double.parseDouble(inputSemesterWeek);
        milesPG = Double.parseDouble(inputMPG);
        gasCost = Double.parseDouble(inputGasCost);
        travelDis = Double.parseDouble(inputTravelDis);
        
        //Force certain variables to be integers - such as weeks in a semeseter
        //and days the class meet.  These should have decimals
        classMeet = (int)classMeet;
        semesterWeek = (int)semesterWeek;

        //One Round Trip
        oneRoundTrip = travelDis / milesPG * gasCost * 2; //Times 2 for both ways
        
        //Number of Round Trips per Semester
        tripsSemester = classMeet * semesterWeek;

        //Total number of miles per Semester
        totalMiles = classMeet * semesterWeek * travelDis * 2;

        //Total cost for the semester (no-sharing)
        totalCost = oneRoundTrip * tripsSemester;

        //Total cost for the semester (sharing with 1 other person)
        totalSharedOne = totalCost / 2;

        //Total cost for the semester (sharing with 2 other people)
        totalSharedTwo = totalCost / 3;

        //Output Data Sheet
        System.out.println("GIVEN THIS DATA");
        System.out.println("---------------");
        System.out.println("Class info:");
        System.out.println("    number days/week class meets: " 
                + (int)classMeet);
        System.out.println("    number weeks in semester: " + (int)semesterWeek);
        System.out.println("Gas info:");
        System.out.println("    car's average mpg: " + (int)milesPG + " miles");
        System.out.println("    price of gas per gallon: $" + gasCost);
        System.out.println("Journey info:");
        System.out.println("    1-way distance to Parkview: " 
                + (int)travelDis + " miles");
        System.out.println();
        System.out.println();

                //The results

        System.out.println("THE RESULTS");
        System.out.println("-----------");
        System.out.println("Number of round trips/semester: " 
                + (int)tripsSemester);
        System.out.println("Total number of miles/semester: " 
                + (int)totalMiles);
        System.out.println("Cost for 1 round-trip (for gas) : $"
                    + String.format("%.2f",oneRoundTrip));
        System.out.printf("Total Cost for semester (for gas) : $"
                + String.format("%.2f",totalCost) + "\n\n");
        System.out.println("Cost per person for the semester");
        System.out.println("--------------------------------");
        System.out.printf("For 1 person: $" + String.format("%.2f",totalCost) 
                + "\n");
        System.out.printf("For 2 people sharing: $" 
                + String.format("%.2f",totalSharedOne) + "\n");
        System.out.printf("For 3 people sharing: $"
                    + String.format("%.2f",totalSharedTwo) + "\n");

    }
 
}
