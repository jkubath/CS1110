/* PROJECT:  Lab8 Exercise D
 * AUTHOR:  Jonah Kubath and Andrew Rayl
 * DESCRIPTION:  Exercise D
 ******************************************************************************/
package lab8.exercised;
import java.util.Scanner;
import java.util.ArrayList;

public class Lab8ExerciseD {

    public static void main(String[] args) {
        
        // WRITE main's CODE HERE
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the length of the array list.");
        int length = scan.nextInt();
        ArrayList array = new ArrayList();
        System.out.println("Enter the numbers for the array.");
        for(int i = 0; i < length; i++)
        {
            System.out.println("What is the number");
            array.add(scan.nextInt());
            
        }
        ArrayList reversedArray = new ArrayList();
        for(int i = array.size() - 1; i >= 0; i--)
        {
            reversedArray.add(array.get(i));
        }
        
       
        for(int i = 0; i < (array.size() / 2); i++)
        {
            
            int size = array.size() - 1 - i;
            int hold = (int)array.get(size);
            array.set(size, array.get(i));
            array.set(i, hold);
        }
        
        
        
        
        
        System.out.println(array);
        System.out.println(reversedArray);
        
        
        
        
        
        
        
    }

}
