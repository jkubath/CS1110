

package com.iluwatar.adapter;
/** 
 * The HelloWorld program implements an application that
 * simply displays "Hello World!" to the standard output
 * @author Jonah Kubath and Andrew Rayl
 * @version 1.0
 * @since Nov 7, 2016
 * @deprecated Nov 7, 2016
 * {@inheritDoc}
 * @see BattleShip
 * 
 * {@linkplain BattleShip}
 * 
 */
public class HelloWorld {
     /* @param none
     */
    public static void main(String[] args)
    {
      // Prints Hello, World! on standard output. {@link BattleShip}
        System.out.println("Hello, World!");
    }
    
    
    
    
    
}
