/* PROJECT:  Lab8 Exercise
 * AUTHOR:  Jonah Kubath and Andrew Rayl
 * DESCRIPTION:  Exercise B
 ******************************************************************************/
package arraylist;

import java.util.Random;
import java.util.ArrayList;

public class ArrayList1 {

    public static void main(String[] args) {

        ArrayList<Integer> list = new ArrayList<Integer>();
        fillList(list);
        System.out.println(list.size());
        ArrayList<Integer> list2 = new ArrayList<Integer>();
        removeDuplicate(list, list2);
        
        fillList(list2);
        
        ArrayList<Integer> list3 = new ArrayList<Integer>();
        removeDuplicate(list2, list3);
        
        System.out.println("done");
        System.out.println(list2.size());
        System.out.println(list3.size());
       
    }

    private static ArrayList<Integer> removeDuplicate(ArrayList list, ArrayList list2) {
        
        for(int i = 0; i < list.size(); i++)
        {
            if(!list2.contains(list.get(i)))
            {
                list2.add(list.get(i));
            }
        }
        return list2;
    }

    private static ArrayList<Integer> fillList(ArrayList list) {
        // WRITE main's CODE HERE
        
        Random rand = new Random();
        for (int i = 0; i < 1000; i++) {
            int number = rand.nextInt(1000);
            list.add(number);
            
        }
        return list;
    }

}
