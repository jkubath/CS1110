/* CLASS:  
 * AUTHOR: Jonah
 * DESCRIPTION:  
 ******************************************************************************/

package lab.pkg5.exercise.pkg2;


public class OddTest {

    public static boolean isOdd(int number)
    {
        boolean integerTest = true;
        if( number % 2 != 0)
            integerTest = true;
        else 
            integerTest = false;
        
        return integerTest;
            
            
    }
}
