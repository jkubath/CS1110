/* CLASS:  
 * AUTHOR: Jonah
 * DESCRIPTION:  
 ******************************************************************************/

package lab.pkg10.exercise.pkg3;


public class Bicycle {

    // WRITE CODE HERE
    
    int speed;
    int pedalCadence;
    int gear;
    
    
    
    
    
    
}
